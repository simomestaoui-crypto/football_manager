<?php
// app/Controllers/HomeController.php

require_once '../app/Models/MatchModel.php';

class HomeController
{
    private $db;
    private $matchModel;

    public function __construct($db)
    {
        $this->db = $db;
        $this->matchModel = new MatchModel($this->db);
    }

    public function index()
    {
        $standings = $this->matchModel->getStandings();
        $page_title = "Classement du Championnat";
        $current_page = "index";

        // Data for view
        $view_data = [
            'standings' => $standings,
            'page_title' => $page_title,
            'current_page' => $current_page
        ];

        // Render View
        $this->render('home/index', $view_data);
    }

    public function calendar()
    {
        $played = $this->matchModel->getPlayed();
        $upcoming = $this->matchModel->getUpcoming();
        $page_title = "Calendrier & Résultats";
        $current_page = "calendar";

        $this->render('home/calendar', compact('played', 'upcoming', 'page_title', 'current_page'));
    }

    public function stats()
    {
        $topScorers = $this->matchModel->getTopScorers();
        $bestAttack = $this->matchModel->getBestAttack();
        $bestDefense = $this->matchModel->getBestDefense();
        $page_title = "Statistiques";
        $current_page = "stats";

        $this->render('home/stats', compact('topScorers', 'bestAttack', 'bestDefense', 'page_title', 'current_page'));
    }

    public function contact()
    {
        $page_title = "Contactez-nous";
        $current_page = "contact";
        $msg_sent = false;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Simulation
            $msg_sent = true;
        }

        $this->render('home/contact', compact('page_title', 'current_page', 'msg_sent'));
    }

    private function render($view, $data = [])
    {
        extract($data);
        include '../app/Views/' . $view . '.php';
    }
}
?>