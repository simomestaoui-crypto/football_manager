<!-- Footer -->
<footer
    style="background: #111; color: #666; padding: 20px; text-align: center; border-top: 1px solid #333; margin-top: 30px;">
    <p>&copy;
        <?php echo date('Y'); ?> Botola Pro Inwi. Tous droits réservés.
    </p>
    <p style="font-size: 0.9rem;">
        <a href="index.php?controller=home&action=contact" style="color: var(--accent); text-decoration: none;">Nous
            contacter</a>
        <span style="margin: 0 10px; color: #444;">|</span>
        <i class="fa-solid fa-phone" style="font-size: 0.8rem;"></i> +212 693-078308
    </p>
</footer>

</div> <!-- Fin .content-wrapper -->
</main>
</div> <!-- Fin .app-container -->

<script src="<?php echo $base_url; ?>/js/script.js"></script>

</body>

</html>