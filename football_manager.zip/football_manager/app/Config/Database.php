<?php
// app/Config/Database.php

class Database
{
    private $host = "127.0.0.1";
    private $db_name = "football_db";
    private $username = "football_admin";
    private $password = "password123";
    private $port = 3306;
    public $conn;

    public function getConnection()
    {
        $this->conn = null;
        try {
            $this->conn = mysqli_connect($this->host, $this->username, $this->password, $this->db_name, $this->port);
        } catch (Exception $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        return $this->conn;
    }
}
?>