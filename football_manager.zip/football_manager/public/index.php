<?php
// public/index.php : Routeur MVC
session_start();

// 1. Config & Database
require_once '../app/Config/Database.php';

// Connexion BDD via Singleton/Classe
$database = new Database();
$db = $database->getConnection();

// 2. Analyse de l'URL
$controllerName = isset($_GET['controller']) ? $_GET['controller'] : 'home';
$actionName = isset($_GET['action']) ? $_GET['action'] : 'index';

// 3. Routage
switch ($controllerName) {
    case 'auth':
        require_once '../app/Controllers/AuthController.php';
        $controller = new AuthController($db);
        break;
    case 'ticket':
        require_once '../app/Controllers/TicketController.php';
        $controller = new TicketController($db);
        break;
    case 'admin':
        require_once '../app/Controllers/AdminController.php';
        $controller = new AdminController($db);
        break;
    case 'home':
    default:
        require_once '../app/Controllers/HomeController.php';
        $controller = new HomeController($db);
        break;
}

// 4. Exécution de l'action
if (method_exists($controller, $actionName)) {
    $controller->{$actionName}();
} else {
    // Fallback si l'action n'existe pas
    $controller->index();
}
?>